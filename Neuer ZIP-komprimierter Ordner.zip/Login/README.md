# loopback-getting-started-intermediate

Please see LoopBack [Getting started part II](http://loopback.io/doc/en/lb3/Getting-started-part-II.html) for the tutorial that walks you through creating this application.

```
$ git clone https://github.com/strongloop/loopback-getting-started-intermediate.git
$ cd loopback-getting-started-intermediate
$ npm install
$ node .
```

---

[More LoopBack examples](https://loopback.io/doc/en/lb3/Tutorials-and-examples.html)
