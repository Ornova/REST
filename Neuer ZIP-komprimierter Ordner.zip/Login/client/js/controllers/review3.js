// Copyright IBM Corp. 2015. All Rights Reserved.
// Node module: loopback-getting-started-intermediate
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT

angular
  .module('app')
  .controller('AllReviewsController', ['$scope', 'Review', function($scope,
      Review) {
    $scope.reviews = Review.find({
      filter: {
        include: [
          'LogIN',
          'reviewer'
        ]
      }
    });
  }])
  .controller('AddReviewController', ['$scope', 'LogIN', 'Review',
      '$state', function($scope, LogIN, Review, $state) {
    $scope.action = 'Add';
    $scope.LogINs = [];
    $scope.selectedShop;
    $scope.review = {};
    $scope.isDisabled = false;

    LogIN
      .find()
      .$promise
      .then(function(LogINs) {
        $scope.LogINs = LogINs;
        $scope.selectedShop = $scope.selectedShop || LogINs[0];
      });

    $scope.submitForm = function() {
      Review
        .create({
          rating: $scope.review.rating,
          comments: $scope.review.comments,
          LogINId: $scope.selectedShop.id
        })
        .$promise
        .then(function() {
          $state.go('all-reviews');
        });
    };
  }])
  .controller('DeleteReviewController', ['$scope', 'Review', '$state',
      '$stateParams', function($scope, Review, $state, $stateParams) {
    Review
      .deleteById({ id: $stateParams.id })
      .$promise
      .then(function() {
        $state.go('my-reviews');
      });
  }])
  .controller('EditReviewController', ['$scope', '$q', 'LogIN', 'Review',
      '$stateParams', '$state', function($scope, $q, LogIN, Review,
      $stateParams, $state) {
    $scope.action = 'Edit';
    $scope.LogINs = [];
    $scope.selectedShop;
    $scope.review = {};
    $scope.isDisabled = true;

    $q
      .all([
        LogIN.find().$promise,
        Review.findById({ id: $stateParams.id }).$promise
      ])
      .then(function(data) {
        var LogINs = $scope.LogINs = data[0];
        $scope.review = data[1];
        $scope.selectedShop;

        var selectedShopIndex = LogINs
          .map(function(LogIN) {
            return LogIN.id;
          })
          .indexOf($scope.review.LogINId);
        $scope.selectedShop = LogINs[selectedShopIndex];
      });

    $scope.submitForm = function() {
      $scope.review.LogINId = $scope.selectedShop.id;
      $scope.review
        .$save()
        .then(function(review) {
          $state.go('all-reviews');
        });
    };
  }])
  .controller('MyReviewsController', ['$scope', 'Review',
      function($scope, Review) {
        // after a refresh, the currenUser is not immediately on the scope
        // So, we're watching it on the scope and load my reviews only then.
        $scope.$watch('currentUser.id', function(value) {
          if (!value) {
            return;
          }
          $scope.reviews = Review.find({
            filter: {
              where: {
                publisherId: $scope.currentUser.id
              },
              include: [
                'LogIN',
                'reviewer'
              ]
            }
          });
        });
  }]);
