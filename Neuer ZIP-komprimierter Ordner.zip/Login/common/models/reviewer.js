'use strict';

module.exports = function(Reviewer) {

};
